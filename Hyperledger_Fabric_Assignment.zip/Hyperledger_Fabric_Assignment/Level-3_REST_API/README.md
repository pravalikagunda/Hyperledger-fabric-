# Level 3 - REST API (Golang) + Dockerfile

This folder provides a simple REST API using Gin framework that demonstrates how to interact with deployed chaincode via the Fabric Gateway client.
The code contains placeholders for connection profile paths, wallet/identity, and MSP values. Replace them with your environment-specific values.

**Build and run locally**
```bash
cd Level-3_REST_API/app
go mod download
go run main.go
```

**Docker build (example)**
```bash
docker build -t asset-api:latest .
docker run -p 8080:8080 asset-api:latest
```

Endpoints (examples):
- `GET /asset/:id` - read an asset
- `POST /asset` - create an asset (JSON body)
- `PUT /asset/:id` - update an asset
- `GET /assets` - list all assets
- `GET /asset/:id/history` - get history for asset

Remember: configure gateway connection (TLS certs, peer endpoint, identity) before using the REST API.
