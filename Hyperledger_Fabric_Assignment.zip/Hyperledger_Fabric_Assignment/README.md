# Hyperledger Fabric Internship Assignment - Ready-to-upload Repo

This repository contains a prepared solution skeleton for the 3-level internship assignment (Hyperledger Fabric).
It uses **Golang** for both chaincode (Level-2) and a sample REST API (Level-3). Level-1 contains setup instructions.

**Contents**
- Level-1_Setup: Instructions to bring up the Fabric test network.
- Level-2_SmartContract: Golang chaincode implementing asset operations.
- Level-3_REST_API: Golang REST API (Gin) that demonstrates how to call the deployed chaincode via Fabric Gateway (stubs & placeholders included) + Dockerfile.

> Important: This is a template and should be tested/adjusted in your environment. Replace placeholder connection/profile values and add your Fabric network crypto materials where required before running the API against a real Fabric network.
