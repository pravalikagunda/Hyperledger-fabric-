# Level 2 - Smart Contract (Golang)

This folder contains a sample chaincode implementing asset operations required by the assignment.

**Files**
- chaincode/asset_transfer.go - Chaincode implementation using fabric-contract-api-go
- chaincode/go.mod - module file

**Build / Test (high-level)**
1. Ensure Go (>=1.16) installed.
2. From `chaincode/` directory:
   ```bash
   go mod download
   go build
   ```
3. Package and install chaincode using Fabric lifecycle commands or use `test-network` scripts.

**Notes**
- The chaincode implements CreateAsset, ReadAsset, UpdateAsset, DeleteAsset, GetAllAssets, GetHistoryForAsset.
- Adjust the module path or imports as needed for your fabric version.
