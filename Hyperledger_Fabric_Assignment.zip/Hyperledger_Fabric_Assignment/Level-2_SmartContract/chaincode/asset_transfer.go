package main

import (
    "encoding/json"
    "fmt"

    "github.com/hyperledger/fabric-contract-api-go/contractapi"
    "github.com/hyperledger/fabric-contract-api-go/metadata"
)

// Asset represents an account/asset in the world state.
type Asset struct {
    DealerID    string `json:"dealerId"`
    MSISDN      string `json:"msisdn"`
    MPIN        string `json:"mpin"`
    Balance     string `json:"balance"`
    Status      string `json:"status"`
    TransAmount string `json:"transAmount"`
    TransType   string `json:"transType"`
    Remarks     string `json:"remarks"`
}

// SmartContract provides functions for managing an Asset
type SmartContract struct {
    contractapi.Contract
}

func (s *SmartContract) CreateAsset(ctx contractapi.TransactionContextInterface, assetID string, dealerId string, msisdn string, mpin string, balance string, status string, transAmount string, transType string, remarks string) error {
    exists, err := s.AssetExists(ctx, assetID)
    if err != nil {
        return err
    }
    if exists {
        return fmt.Errorf("the asset %s already exists", assetID)
    }

    asset := Asset{
        DealerID:    dealerId,
        MSISDN:      msisdn,
        MPIN:        mpin,
        Balance:     balance,
        Status:      status,
        TransAmount: transAmount,
        TransType:   transType,
        Remarks:     remarks,
    }
    assetJSON, err := json.Marshal(asset)
    if err != nil {
        return err
    }

    return ctx.GetStub().PutState(assetID, assetJSON)
}

func (s *SmartContract) ReadAsset(ctx contractapi.TransactionContextInterface, assetID string) (*Asset, error) {
    assetJSON, err := ctx.GetStub().GetState(assetID)
    if err != nil {
        return nil, fmt.Errorf("failed to read world state: %v", err)
    }
    if assetJSON == nil {
        return nil, fmt.Errorf("the asset %s does not exist", assetID)
    }

    var asset Asset
    err = json.Unmarshal(assetJSON, &asset)
    if err != nil {
        return nil, err
    }
    return &asset, nil
}

func (s *SmartContract) UpdateAsset(ctx contractapi.TransactionContextInterface, assetID string, dealerId string, msisdn string, mpin string, balance string, status string, transAmount string, transType string, remarks string) error {
    exists, err := s.AssetExists(ctx, assetID)
    if err != nil {
        return err
    }
    if !exists {
        return fmt.Errorf("the asset %s does not exist", assetID)
    }

    asset := Asset{
        DealerID:    dealerId,
        MSISDN:      msisdn,
        MPIN:        mpin,
        Balance:     balance,
        Status:      status,
        TransAmount: transAmount,
        TransType:   transType,
        Remarks:     remarks,
    }
    assetJSON, err := json.Marshal(asset)
    if err != nil {
        return err
    }

    return ctx.GetStub().PutState(assetID, assetJSON)
}

func (s *SmartContract) DeleteAsset(ctx contractapi.TransactionContextInterface, assetID string) error {
    exists, err := s.AssetExists(ctx, assetID)
    if err != nil {
        return err
    }
    if !exists {
        return fmt.Errorf("the asset %s does not exist", assetID)
    }
    return ctx.GetStub().DelState(assetID)
}

func (s *SmartContract) AssetExists(ctx contractapi.TransactionContextInterface, assetID string) (bool, error) {
    assetJSON, err := ctx.GetStub().GetState(assetID)
    if err != nil {
        return false, err
    }
    return assetJSON != nil, nil
}

func (s *SmartContract) GetAllAssets(ctx contractapi.TransactionContextInterface) ([]*Asset, error) {
    resultsIterator, err := ctx.GetStub().GetStateByRange("", "")
    if err != nil {
        return nil, err
    }
    defer resultsIterator.Close()

    var assets []*Asset
    for resultsIterator.HasNext() {
        queryResponse, err := resultsIterator.Next()
        if err != nil {
            return nil, err
        }
        var asset Asset
        err = json.Unmarshal(queryResponse.Value, &asset)
        if err != nil {
            return nil, err
        }
        assets = append(assets, &asset)
    }
    return assets, nil
}

func (s *SmartContract) GetHistoryForAsset(ctx contractapi.TransactionContextInterface, assetID string) (string, error) {
    resultsIterator, err := ctx.GetStub().GetHistoryForKey(assetID)
    if err != nil {
        return "", err
    }
    defer resultsIterator.Close()

    type HistoryRecord struct {
        TxId      string `json:"txId"`
        IsDelete  bool   `json:"isDelete"`
        Value     *Asset `json:"value"`
        Timestamp string `json:"timestamp"`
    }

    var records []HistoryRecord

    for resultsIterator.HasNext() {
        modification, err := resultsIterator.Next()
        if err != nil {
            return "", err
        }
        var asset Asset
        if modification.Value != nil {
            _ = json.Unmarshal(modification.Value, &asset)
        }
        rec := HistoryRecord{
            TxId:     modification.TxId,
            IsDelete: modification.IsDelete,
            Value:    &asset,
            Timestamp: modification.Timestamp.String(),
        }
        records = append(records, rec)
    }
    b, err := json.Marshal(records)
    if err != nil {
        return "", err
    }
    return string(b), nil
}

func main() {
    chaincode, err := contractapi.NewChaincode(&SmartContract{})
    if err != nil {
        fmt.Printf("Error create chaincode: %s", err.Error())
        return
    }
    chaincode.Info.Version = "0.0.1"
    chaincode.Info.Description = "Asset transfer chaincode for internship assignment"
    chaincode.Info.License = &metadata.LicenseMetadata{Name: "Apache-2.0"}

    if err := chaincode.Start(); err != nil {
        fmt.Printf("Error starting chaincode: %s", err.Error())
    }
}
