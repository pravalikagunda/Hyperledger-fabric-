# Level 1 - Hyperledger Fabric Test Network Setup

Follow these high-level steps to set up the Fabric test network (local development):

1. Install prerequisites (Docker, Docker Compose, Go, Node.js, cURL, jq).
2. Clone fabric-samples and download Fabric binaries and docker images:
   - https://github.com/hyperledger/fabric-samples
   - Follow the `test-network` instructions in the Fabric docs: https://hyperledger-fabric.readthedocs.io/

3. Start test network (example from fabric-samples):
   ```bash
   cd fabric-samples/test-network
   ./network.sh up createChannel -c mychannel -ca
   ```
4. Deploy chaincode (packaged in Level-2_SmartContract). Example (after building chaincode):
   ```bash
   # from fabric-samples/test-network
   ./network.sh deployCC -ccn asset_transfer -ccp <path-to-level-2-chaincode> -ccl go
   ```

Add screenshots/proof to `Level-1_Setup/screenshots/` after you run these commands.
